import './App.css'
import Container from './Container.js'
export default function App(){
  return(
    <>
      <h1>Salem Cafe</h1>
      <Container />
    </>
  )
}
