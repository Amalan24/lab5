import { useState } from 'react'
import './App.css'
export default function Container(){
    const [muffins,setmuffins] = useState(100);
    const [cookies,setcookies] = useState(100);
    const [one,setone] = useState(0);
    const [two,settwo] = useState(0);
    const [totalItems,setTotalItems] = useState(0);
    const onechange =(e)=>{
        setone(e.target.value);
    }
    const twochange =(e)=>{
        settwo(e.target.value);
    } 
    function buy_one(){
        if(one<=muffins){       
            setmuffins(muffins-one)
            setTotalItems(Number(totalItems)+Number(one))
        }
    }
    function buy_two(){
        if(two<=cookies){       
            setcookies(cookies-two);
            setTotalItems(Number(totalItems)+Number(two))
        }
    }   
    return(
        <div className='blocks'>
            <p>Blueberry Muffins : <input type='number' name='muffins' onChange={onechange} min='0'/> <button onClick={buy_one}>Buy</button><br></br></p>
            <p>Total count : {muffins}</p>
            <p>Chocolate Chip Cookies  : <input type='number' name='cookies' onChange={twochange} min='0'></input> <button onClick={buy_two}>Buy</button></p>
            <p>Total count : {cookies}</p>
            <p>Total Item sold : {totalItems}</p>
        </div>
    )
}   