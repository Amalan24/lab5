import React, { useState } from 'react';
import EnergyCalculator from './EnergyCalculator';
import Result from './Result';

const EnergyForm = () => {
  const [consumedUnits, setConsumedUnits] = useState(0);
  const defaultSubsidyAmount = 250;
  const [charges, setCharges] = useState(null);

  const handleConsumedUnitsChange = (e) => {
    setConsumedUnits(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();   
    const calculatedCharges = EnergyCalculator(consumedUnits, defaultSubsidyAmount);
    setCharges(calculatedCharges);
  };

  return (
    <div>
        <h1>Shan energies PVT Ltd</h1><br/>
        <h2>Bill Calculator</h2><br/>
      <form onSubmit={handleSubmit}>
        <div id="outline-input">
        <label for="bill">Enter the consumed unit : </label>
        <input type="number" min="0" id="bill" value={consumedUnits} onChange={handleConsumedUnitsChange}/>
        <button type="submit">Submit</button>
    </div><br/><br/>
      </form>
      {charges && <Result charges={charges} />}
    </div>
  );
};

export default EnergyForm;