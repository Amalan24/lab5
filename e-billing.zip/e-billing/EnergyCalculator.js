const EnergyCalculator = (consumedUnits, defaultSubsidyAmount) => {
    let currentCharges = 0;
    let fixedCost = 0;
    let subsidyFixedCost = 0;
    let newSubsidy = 0;
    let netAmount = 0;
  
    if (consumedUnits <= 150 && consumedUnits!=="") {
      currentCharges = consumedUnits * 0;
    } else if (consumedUnits > 150 && consumedUnits <= 350) {
      currentCharges = 100 + (consumedUnits * 3.75);
    } else if (consumedUnits > 350 && consumedUnits <= 450) {
      currentCharges = 100 + (200 * 3.75) + ((consumedUnits-350) * 4+250);
    } else if (consumedUnits > 450 && consumedUnits <= 600) {
      currentCharges = (100 + 200 * 3.75) + (250+100 * 4) + (300+(consumedUnits - 450) * 4.25);
    } else if (consumedUnits > 600) {
      currentCharges = (100 +200 * 3.75) + (250+100 * 4) + (300+150 * 4.25) + (400+(consumedUnits - 600) * 5);
    }
  
    fixedCost = 50;
    subsidyFixedCost = 0;
    newSubsidy = defaultSubsidyAmount;
    netAmount = currentCharges + fixedCost - subsidyFixedCost - newSubsidy;
    if(netAmount<0){netAmount=0;}
  
    return {
      consumedUnits,
      currentCharges,
      fixedCost,
      subsidyFixedCost,
      newSubsidy,
      netAmount,
    };
  };
  
  export default EnergyCalculator;