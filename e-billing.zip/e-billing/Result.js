import React from 'react';
import './index.css';

const Result = ({ charges }) => {
    const {consumedUnits, currentCharges, netAmount} = charges;

    return (
        <div id="outline-output">
        <table for="output">
            <tr>
                <td>Consumed Units : </td>
                <td id="consumed-units">{consumedUnits}</td>
            </tr>
            <tr>
                <td>Total Current Charges Rs. </td>
                <td id="total-current-charges1">{currentCharges}</td>
            </tr>
            <tr>
                <td>Current Charges Rs. </td>
                <td id="total-current-charges2">{currentCharges}</td>
            </tr>
            <tr>
                <td>Fixed Cost Rs.(+) </td>
                <td>50.0</td>
            </tr>
            <tr>
                <td>Subsidy Fixed Cost Rs.(-) </td>
                <td>0.0</td>
            </tr>
            <tr>
                <td>New Subsidy Rs.(-) </td>
                <td>250.0</td>
            </tr>
            <tr>
                <td>Net Amount Rs. </td>
                <td id="net-amount">{netAmount}</td>
            </tr>
        </table>
    </div>
    );
};

export default Result;