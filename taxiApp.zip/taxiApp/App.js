import React,{useState} from "react";
import Result from './Result';
import  './App.css';

function App() {
  const distance = {
    'Guindy':[{dest:'Little Mount',km:1},{dest:'Anna University',km:3},{dest:'Adayar',km:6},{dest:'Besant nagar',km:7},{dest:'Velachery',km:4.5},{dest:'Thiruvanmayur',km:8}],
    'Little Mount':[{dest:'Guindy',km:2},{dest:'Anna University',km:1.2},{dest:'Adayar',km:4},{dest:'Besant nagar',km:5.2},{dest:'Velachery',km:6.5},{dest:'Thiruvanmayur',km:6.5}],
    'Anna University':[{dest:'Guindy',km:2},{dest:'Little Mount',km:2},{dest:'Adayar',km:3},{dest:'Besant nagar',km:4},{dest:'Velachery',km:8.2},{dest:'Thiruvanmayur',km:6}],
    'Besant nagar':[{dest:'Guindy',km:6.7},{dest:'Little Mount',km:7.1},{dest:'Adayar',km:1.1},{dest:'Anna University',km:4},{dest:'Velachery',km:3},{dest:'Thiruvanmayur',km:6}],
    'Thiruvanmayur':[{dest:'Guindy',km:7},{dest:'Little Mount',km:7},{dest:'Adayar',km:2.4},{dest:'Anna University',km:6.4},{dest:'Besant nagar',km:3},{dest:'Velachery',km:5.7}],
    'Velachery':[{dest:'Guindy',km:3},{dest:'Little Mount',km:2},{dest:'Adayar',km:8},{dest:'Anna University',km:4},{dest:'Besant nagar',km:8.8},{dest:'Thiruvanmayur',km:7.1}],
    'Adayar':[{dest:'Guindy',km:5},{dest:'Little Mount',km:4.2},{dest:'Anna University',km:6},{dest:'Besant nagar',km:1.1},{dest:'Thiruvanmayur',km:3},{dest:'Velachery',km:7}]
  }
  const [boardPoint,setBoardPoint] = useState('');
  const [arrival,setArrival] = useState('');
  const [dateTime,setDateTime] = useState('');
  const [carType,setCarType] = useState('');
  const [pricePerKm,setPrice] = useState(0);
  const [fare,setFare] = useState('');
  const [showResult, setShowResult] = useState(false);


  const setCar = (e) => { 
      setPrice(e.target.options[e.target.options.selectedIndex].value)
      setCarType(e.target.selectedIndex.textContent)
  }

  const travelFare = ()=>{
    if(boardPoint&&arrival){
      const destination = distance[boardPoint].find((item) => item.dest === arrival);
    if(destination){
        return destination.km*pricePerKm;
    }
  }
    else{setArrival('')}
  }

  const handleSubmit = (e) =>{
      e.preventDefault();
      setFare(travelFare());
  }

  const handleClick = () => {
    setShowResult(true);
  };

  return (
    <div id="outline">
      <form onSubmit={handleSubmit}>
      <div className="App">
        <h1>Go Taxi</h1>
        <label for="start-point">Start point : 
          <input id="start-point" list="start-city" placeholder='Enter pickup location' value={boardPoint} onChange={(e) => setBoardPoint(e.target.value)} />
          <datalist id="start-city">
            <option>Guindy</option>
            <option>Little Mount</option>
            <option>Anna University</option>
            <option>Besant nagar</option>
            <option>Thiruvanmayur</option>
            <option>Velachery</option>
            <option>Adayar</option>
          </datalist>
        </label><br /><br />
        <label for="end-point">Destination : 
          <input type="text" list="end-city" id="end-point" placeholder='Enter drop location' value={arrival} onChange={(e) => setArrival(e.target.value)} />
          <datalist id="end-city">
            <option>Guindy</option>
            <option>Little Mount</option>
            <option>Anna University</option>
            <option>Besant nagar</option>
            <option>Thiruvanmayur</option>
            <option>Velachery</option>
            <option>Adayar</option>
          </datalist>
        </label><br /><br />
        <label for="date-time">Destination : 
          <input type='datetime-local' id="date-time" value={dateTime} onChange={(e) => setDateTime(e.target.value)} />
        </label><br /><br />
        <label for="car-type">Type of car : 
          <select id="car-type" value={pricePerKm} onClick={setCar} onChange={setCar}>
            <option></option>
            <option value={15}>Hatchback</option>
            <option value={20}>Sedan</option>
            <option value={30}>SUV</option>
          </select>
        </label><br /><br />
        <button type="submit" onClick={handleClick}>Book</button>
      </div>
      {showResult && fare &&dateTime && <Result charges={[fare,boardPoint,arrival,carType,dateTime]} />}
      </form>
      
    </div>

  );
}

export default App;