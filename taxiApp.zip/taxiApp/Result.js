import React from 'react';

const Result=({charges})=>{
    
        if(charges[1]==='' || charges[2]===''){
            return;           
        }
        else{
        return(<div id="result-outline">
          <h1>Go Taxi</h1>
          <p>Your Journey from <strong>{charges[1]} </strong>
              to <strong>{charges[2]} </strong></p>
          <p>Taxi fare: ₹{charges[0]}</p>
          <p>Happy Journey!!!</p>
        </div>)
        }
}

export default Result;