import React, { useState } from 'react';
import SavingsCalculator from './SavingsCalculator';
import Result from './Result';

const SavingsForm = () => {
  const [annualSalary, setAnnualSalary] = useState('');
  const [portionSaved, setPortionSaved] = useState('');
  const [totalCost, setTotalCost] = useState('');
  const [months, setMonths] = useState(null);

  const handleAnnualSalaryChange = (e) => {
    setAnnualSalary(e.target.value);
  };

  const handlePortionSavedChange = (e) => {
    setPortionSaved(e.target.value);
  };

  const handleTotalCostChange = (e) => {
    setTotalCost(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

  
    const downPayment = totalCost * 0.25;
    const monthlySal = annualSalary / 12;
    const monthlySavings = monthlySal * (portionSaved);
    const calculatedMonths = SavingsCalculator(monthlySavings, downPayment);

    
    setMonths(calculatedMonths);
  };

  return (
    <div>
      <h1>Sales and Purchase Agreement</h1>
      <form onSubmit={handleSubmit}>
        <div>
        <label>Annual Salary (Rs.) : </label>
          <input type="number" value={annualSalary} onChange={handleAnnualSalaryChange} />
        
          <label>Portion of Salary to be Saved (eg: 0.1 for 10%): </label>
          <input type="number" value={portionSaved} onChange={handlePortionSavedChange}/>
        
          <label>Cost of your Dream Home (Rs.) : </label>
          <input type="number" value={totalCost} onChange={handleTotalCostChange} />
        <button type="submit">Calculate</button>
        </div>
      </form>
      {months && <Result months={months} />}
    </div>
   
  );
};

export default SavingsForm;