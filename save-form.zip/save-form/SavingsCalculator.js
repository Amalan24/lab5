const SavingsCalculator = (monthlySavings, downPayment) => {
    const months = Math.ceil(downPayment / monthlySavings);
    return months;
  };
  
  export default SavingsCalculator;