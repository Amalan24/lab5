import { useState } from 'react'
import './App.css'
export default function Container(){
    const [muffins,setmuffins] = useState(100);
    const [cookies,setcookies] = useState(100);
    const [one,setone] = useState(0);
    const [two,settwo] = useState(0);
    const [prevone,setprevone] = useState(0);
    const [prevtwo,setprevtwo] = useState(0);
    const onechange =(e)=>{
        setone(e.target.value);
    }
    const twochange =(e)=>{
        settwo(e.target.value);
    } 
    function buy_one(){
        setmuffins(muffins-one)
        setprevone(one);
    }
    function buy_two(){
        setcookies(cookies-two);
        setprevtwo(two);
    }   
    return(
        <div className='blocks'>
            <p>Blueberry Muffins : <input type='text' name='muffins' onChange={onechange} placeholder='....'></input> <button onClick={buy_one}>Buy</button><br></br></p>
            <p>Total count : {muffins}</p>
            <p>Chocolate Chip Cookies  : <input type='text' name='cookies' onChange={twochange} placeholder='......'></input> <button onClick={buy_two}>Buy</button></p>
            <p>Total count : {cookies}</p>
            <p>previous buy</p>
            <p>blueberry muffins : {prevone}</p>
            <p>chocolate chip cookies  : {prevtwo}</p>
            <p>{}</p>
        </div>
    )
}