import React from 'react';

const Result = ({ months }) => {
  return <div id="result">Number of Months to Save: {months} Months.</div>;
};

export default Result;